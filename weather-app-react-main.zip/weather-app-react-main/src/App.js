import React, { useState, useEffect, useRef } from 'react';
import './App.css';

function App() {
    const [location, setLocation] = useState('');
    const [weather, setWeather] = useState(null);
    const [forecast, setForecast] = useState(null);
    const [hourlyForecast, setHourlyForecast] = useState(null); // State for hourly forecast
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false); // Loading state
    const rainRef = useRef(null);
    const starRef = useRef(null);
    const cloudRef = useRef(null);

    useEffect(() => {
        createStars();
        const currentStarRef = starRef.current;
        return () => {
            if (currentStarRef) {
                currentStarRef.innerHTML = '';
            }
        };
    }, []);

    useEffect(() => {
        if (weather) {
            const weatherMain = weather.weather[0].main.toLowerCase();
            document.body.className = weatherMain.replace(/\s/g, '');

            if (rainRef.current) {
                rainRef.current.classList.toggle('active', weatherMain === 'rain' || weatherMain === 'drizzle' || weatherMain === 'thunderstorm');
            }
            if (cloudRef.current) {
                cloudRef.current.style.display = weatherMain.includes('cloud') || weatherMain.includes('mist') || weatherMain.includes('fog') || weatherMain.includes('haze') ? 'block' : 'none';
            }

        } else {
            document.body.className = '';
            if (rainRef.current) {
                rainRef.current.classList.remove('active');
            }
            if (cloudRef.current) {
                cloudRef.current.style.display = 'none';
            }
        }
    }, [weather]);

    const fetchWeather = async (e) => {
        e.preventDefault();
        if (!location) return;

        setLoading(true); // Set loading to true when fetching starts
        setError(''); // Clear any previous errors
        setWeather(null);
        setForecast(null);
        setHourlyForecast(null); // Clear hourly forecast

        try {
            const currentWeatherResponse = await fetch(
                `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=25bda5ab2e3641bb5eb7f8810f20b11a&units=metric`
            );
            const currentWeatherData = await currentWeatherResponse.json();

            const forecastResponse = await fetch(
                `https://api.openweathermap.org/data/2.5/forecast?q=${location}&appid=25bda5ab2e3641bb5eb7f8810f20b11a&units=metric`
            );
            const forecastData = await forecastResponse.json();

            if (currentWeatherResponse.ok && forecastResponse.ok) {
                setWeather(currentWeatherData);
                setForecast(forecastData.list.filter((item, index) => index % 8 === 0).slice(0, 3));
                setHourlyForecast(forecastData.list.slice(0, 5)); // Get first 5 hourly forecasts
                setError('');
            } else {
                setError(currentWeatherData.message || forecastData.message || 'Error fetching data');
            }
        } catch (err) {
            console.error(err);
            setError('Error fetching weather data.');
        } finally {
            setLoading(false); // Set loading to false after fetching is complete
        }
    };

    const createStars = () => {
        if (!starRef.current) return;
        starRef.current.innerHTML = '';
        const numStars = 150;
        for (let i = 0; i < numStars; i++) {
            const star = document.createElement('div');
            star.classList.add('star');
            const sizeClass = ['star-small', 'star-medium', 'star-large'][Math.floor(Math.random() * 3)];
            star.classList.add(sizeClass);
            star.style.top = `${Math.random() * 100}%`;
            star.style.left = `${Math.random() * 100}%`;
            starRef.current.appendChild(star);
        }
    };

    const createRainDrops = () => {
        const rainContainer = rainRef.current;
        if (!rainContainer) return;
        rainContainer.innerHTML = '';
        const numDrops = 200;
        for (let i = 0; i < numDrops; i++) {
            const drop = document.createElement('div');
            drop.classList.add('rain-drop');
            drop.style.left = `${Math.random() * 100}%`;
            drop.style.animationDelay = `${Math.random() * 2}s`;
            drop.style.setProperty('--delay', `${i * 0.03}s`);
            rainContainer.appendChild(drop);
        }
    };

    useEffect(() => {
        createRainDrops();
    }, []);

    const getDayName = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { weekday: 'long' });
    };

    const getTime = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <div className="app">
            {weather && <div className="stars" ref={starRef}></div>}
            {weather && <div className="rain" ref={rainRef}></div>}
            <div className="cloud-container" ref={cloudRef}>
                {weather && <div className="cloud"><img src="/cloud.png" alt="Cloud" /></div>}
            </div>

            <h1 className="title">Weather App</h1>
            <form onSubmit={fetchWeather} className="form">
                <input type="text" placeholder="Enter location" value={location} onChange={(e) => setLocation(e.target.value)} className="input" />
                <button type="submit" className="button" disabled={loading}>
                    {loading ? <div className="loader"></div> : 'Get Weather'}
                </button>
            </form>
            {error && <p className="error">{error}</p>}
            {weather && (
                <div className="weather-info">
                    <div className="current-info">
                        <div className="location-info">
                            <p className="current-location">Current Location</p>
                            <h2 className="location">
                                {weather.name}, {weather.sys.country}
                            </h2>
                        </div>
                        <div className="weather-condition">
                            <img src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`} alt="weather icon" className="large-icon" />
                            <p className="temp-main">{Math.round(weather.main.temp)}°C</p>
                        </div>
                    </div>
                    <p className="description">{weather.weather[0].description}</p>
                    <div className="temp-range">
                        <p>Min: {Math.round(weather.main.temp_min)}°C</p>
                        <p>Max: {Math.round(weather.main.temp_max)}°C</p>
                    </div>
                    <p>Feels like: {Math.round(weather.main.feels_like)}°C</p>
                    <p>Humidity: {weather.main.humidity}%</p>
                    <p>Wind Speed: {weather.wind.speed} m/s</p>
                    {weather.wind.gust && <p>Wind Gust: {weather.wind.gust} m/s</p>}
                    <p>Wind Direction: {weather.wind.deg}°</p>

                    {hourlyForecast && (
                        <div className="hourly-forecast">
                            <h3>Hourly Forecast (Next 5 Hours)</h3>
                            <div className="hourly-container">
                                {hourlyForecast.map((item, index) => (
                                    <div className="hourly-item" key={index}>
                                        <p>{getTime(item.dt_txt)}</p>
                                        <img src={`https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png`} alt="hourly forecast icon" className="small-icon" />
                                        <p>{Math.round(item.main.temp)}°C</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    <div className="forecast">
                        <h3>3-Day Forecast</h3>
                        <div className="forecast-container">
                            {forecast && forecast.map((item, index) => (
                                <div className="forecast-item" key={index}>
                                    <p>{getDayName(item.dt_txt)}</p>
                                    <img src={`https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png`} alt="forecast icon" className="forecast-icon" />
                                    <p>Temp: {Math.round(item.main.temp)}°C</p>
                                    <p>Humidity: {item.main.humidity}%</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default App;